package com.宝贝.作业;

public class AptitudeHandSet extends Phone implements Network,Play,TakePicture{

    public AptitudeHandSet() {
    }

    public AptitudeHandSet(String brand, String type) {
        super(brand, type);
    }

    @Override
    public void networkConn() {
        System.out.println("成功接入网络......");
    }

    @Override
    public void TakePictures() {
        System.out.println("咔嚓...拍照成功");

    }

    @Override
    public void play(String incontent) {
        System.out.println("正在播放电视剧:《"+ incontent + "》......");

    }

    @Override
    public void call() {
        System.out.println("视频通话......");

    }

    @Override
    public void sendInfo() {
        System.out.println("发送图文彩信......");

    }
}
