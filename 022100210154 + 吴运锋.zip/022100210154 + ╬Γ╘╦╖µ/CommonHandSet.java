package com.宝贝.作业;

import javax.swing.*;

public  class CommonHandSet extends Phone implements Play {
    public CommonHandSet() {
    }

    public CommonHandSet(String brand, String type) {
        super(brand, type);
    }

    @Override
    public void call() {
        System.out.println("语音通话......");
    }

    @Override
    public void sendInfo() {
        System.out.println("发送文字短信.......");
    }


    @Override
    public void play(String incontent) {
       System.out.println("播放音乐{" + incontent + "}");

    }
}
