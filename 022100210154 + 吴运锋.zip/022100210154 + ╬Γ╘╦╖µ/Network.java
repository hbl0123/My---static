package com.宝贝.作业;
//上网接口
public interface Network {
    public void networkConn();
}
//拍照接口
interface TakePicture{
    public void TakePictures();
}
//播放接口
interface Play{
    public void play(String incontent);
}

