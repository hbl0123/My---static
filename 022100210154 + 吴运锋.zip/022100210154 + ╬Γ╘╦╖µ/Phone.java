package com.宝贝.作业;

public abstract class Phone {
    private String brand;
    private String type;

    //构造方法
    public Phone() {
    }

    public Phone(String brand, String type) {
        this.brand = brand;
        this.type = type;
    }


    //set and  get
    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    //手机型号和品牌的方法
    public void info(){
        System.out.println("这是一款型号为" + type + "de" + brand + "的手机");
    }
    //打电话方法
    public abstract void call();
    //发短信的方法
    public abstract void sendInfo();

}
