package com.宝贝.作业;

public class Test {
    public static void main(String[] args) {
        //普通手机
        System.out.println("--------------普通手机----------------------");
        CommonHandSet c = new CommonHandSet("飞利浦","E315");
        c.info();
        c.sendInfo();
        c.call();
        c.play("东方红");
        //智能手机
        System.out.println("--------------智能手机------------------------");
        AptitudeHandSet a = new AptitudeHandSet("Apple","14Plus");
        a.info();
        a.sendInfo();
        a.call();
        a.networkConn();
        a.TakePictures();
        a.play("漂洋过海来看你");
    }



}
